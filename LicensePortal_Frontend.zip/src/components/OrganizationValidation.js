export default function Validate(values) {
    let errors = {};
    if (!values.orgName) {
      errors.orgName = 'Name is required';
    }

    if (!values.orgEmailAdd) {
        errors.orgEmailAdd = 'Email is required';
      } else if (!/\S+@\S+\.\S+/.test(values.orgEmailAdd)) {
        errors.orgEmailAdd = 'Email is invalid';
      }

      if (!values.orgConNumber) {
        errors.orgConNumber = 'Contact No is required';
      }
      if (!values.orgAddress) {
        errors.orgAddress = 'Address is required';
      }
      if (!values.postCode) {
        errors.postCode = 'Post Code is required';
      }
      if (!values.OrgType_name) {
        errors.OrgType_name = 'Organization Type is required';
      }
      if (!values.Description) {
        errors.Description = 'Description is required';
      }
    
  
    return errors;
  };
  