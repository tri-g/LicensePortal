export default function Validate(values) {
    let errors = {};
    if (!values.username) {
      errors.username = 'User Name is required';
    }

    if (!values.email) {
        errors.email = 'Email Id is required';
      } else if (!/\S+@\S+\.\S+/.test(values.email)) {
        errors.email = 'Email Id is invalid';
      }
  
    return errors;
  };
  