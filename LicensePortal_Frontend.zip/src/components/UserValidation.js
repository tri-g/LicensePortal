export default function Validate(values) {
    let errors = {};
    if (!values.userName) {
      errors.userName = 'Name is required';
    }

    if (!values.emailAddress) {
        errors.emailAddress = 'Email is required';
      } else if (!/\S+@\S+\.\S+/.test(values.emailAddress)) {
        errors.emailAddress = 'Email is invalid';
      }

      if (!values.contactNumber) {
        errors.contactNumber = 'Contact No is required';
      }
      if (!values.address) {
        errors.address = 'Address is required';
      }

      if (!values.password) {
        errors.password = 'Password is required';
      } else if (values.password.length <1) {
        errors.password = 'Password must be 8 or more characters';
      }
  
    return errors;
  };
  