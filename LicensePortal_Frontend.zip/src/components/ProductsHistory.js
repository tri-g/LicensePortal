import {Modal} from "react-bootstrap";
import React, {useState} from "react";
import Service from "../app/service/service.js";
import { useHistory } from "react-router-dom";

export default function ProductsHistory({id, name, desc, code, version,orgname,org,val,initialState}) {

    const history = useHistory();

  const [info, setInfo] = useState(initialState);
  const handleClose = () => setShow(false);
  const [submitted, setSubmitted] = useState(false);

  const handleShow = () =>{setShow(true);setShow2(true);
  setName(name);
  setDesc(desc);
  setCode(code);
  setVersion(version);

}
  const [showModal, setShow] = useState(false);
  const handleShow1 = () => setShow1(true);
  const [show1, setShow1] = useState(false);
  const [show2, setShow2] = useState(false);


  const handleClose1 = () => {setShow1(false);}
  const deleteuser = () => {
   
    Service.deleteProduct(id)
      .then(response => {
        console.log(response.data);
        history.push('/products');
        history.go(0);

      })
      .catch(e => {
        console.log(e);
      });
  };

  const [pid, setId] = useState(id);
  const [pname, setName] = useState(name);
  const [pdesc, setDesc] = useState(desc);
  const [pcode, setCode] = useState(code);
  const [pversion, setVersion] = useState(version);
  const [valu, setValue] = useState(val);


  const saveInfo = () => {

    var data = {
        prdName: pname,
        prdDesc:pdesc,
        productCode: pcode,
        prdVersion:pversion ,
        orgID:+valu
    };
   
  
    console.log(data);
    Service.updateprod(data,id)
      .then(response => {
        console.log("data");
        setInfo({
          
        });
        console.log(data);

        setSubmitted(true);
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  };

  function success(){
    
    window.location.reload();
  }
  return (
    <>                                
                                    
                                    <tr>
                                        <td>
                                           {name}
                                        </td>
                                        <td>
                                          {desc}
                                        </td>
                                        <td>
                                            {code}
                                        </td>
                                        <td>
                                            {version}
                                        </td>
                                        <td>
                                            {orgname}
                                        </td>
                                        <td>
                                        <button className="buttonstyle"  style={{paddingRight: "10px"}} onClick={handleShow}><i className="fa fa-pencil"  aria-hidden="true" style={{paddingRight: "5px"}}  data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button>
                                        <button className="buttonstyle" onClick={handleShow1}><i className="fa fa-trash" aria-hidden="true" data-toggle="modal" data-target="#myModal" style={{color:"darkmagenta"}}></i></button> 
                                        </td>
                                       
                                    </tr>
                                    
                                     <Modal id="center" show={showModal} onHide={handleClose}>      
                                    <div className="modal-dialog" style={{width: "100%",margin:"0px",padding:"0px"}}>
      <div className="modal-content">
      <div className="modal-header">
            <h5><strong>Edit User</strong></h5>
           <button type="button" className="close"  onClick={handleClose} data-dismiss="modal">&times;</button>
        </div>


        <div className="modal-body">
        {submitted ? (
        <div>
    <Modal id="center" show={show2} onHide={handleClose1}>
          <div className="modal-body">
          <h2>Product Edited Successfully!</h2>
       
          <input type="reset" className="btn btn-secondary" style={{width:"10%",float:"right",height:"3%"}} onClick={success} value="OK"/>
             
        </div>
        </Modal>
    </div>
      ) : (
            <form className="form" role="form" autoComplete="off">
              
         
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Name</label>
                    <div className="col-lg-7">
                        <input id="id1" className="form-control"  type="text" id="userName" name="userName"  onChange={(e) => setName(e.currentTarget.value)} value={pname}  placeholder="Product Name"/>
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Description</label>
                    <div className="col-lg-7">
                        <input id="id2" className="form-control" type="email" id="emailAddress" name="emailAddress" onChange={(e) => setDesc(e.currentTarget.value)} value={pdesc} placeholder="Product Description"/>
                    </div>
                </div>

                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Code</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="contactNumber" name="contactNumber" onChange={(e) => setCode(e.currentTarget.value)} value={pcode}  placeholder="Product Code"/>
                    </div>
                </div>

               <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Version</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="address" name="address"  onChange={(e) => setVersion(e.currentTarget.value)} value={pversion}  placeholder="Product Version"/>
                    </div>
                </div>
              
                <div className="form-group row">
            <label className="col-lg-5 col-form-label form-control-label" htmlFor="licensetype">Organization</label>
           <div className="col-lg-7">
             <select className="form-control selectpicker" id="select-country" data-live-search="true" name="org" value={valu}
      onChange={(e) => setValue(e.currentTarget.value)}>
            
             {org.map((item,value) => (
        <option
          key={value}
          value={item.orgID}
        >
         {item.orgName}
        </option>
      ))}
          </select>
          
          </div></div>
                

            <div className="row" style={{padding:"10px"}}></div>
                <div className="form-group row">
                    <label className="col-lg-6 col-form-label form-control-label"></label>
                    <div className="col-lg-3">
                        <input type="reset" className="btn btn-secondary" onClick={handleClose} value="Cancel"/>
                        </div>
                        <div className="col-lg-3">
                            <input type="button" className="btn btn-primary" value="Submit" onClick={saveInfo} data-toggle="modal" data-target="#myModal"/>
                        </div>
                    </div>
                </form>
                )}

            </div>






        </div></div>
                                    </Modal>   

           <Modal show={show1} onHide={handleClose1} style={{top:"30%"}}>
          <div className="modal-body">
          <h5> Are you sure you want to continue?</h5>
       <div style={{textAlign:'center'}}>
          <input type="reset" className="btn btn-secondary" style={{width:"10%",height:"3%",marginRight:"10px"}} onClick={deleteuser} value="Yes"/>
          <input type="reset" className="btn btn-secondary" style={{width:"10%",height:"3%"}} onClick={handleClose1} value="No"/>
          </div>
        </div>
      </Modal>              
                           
    </>
  )
}
