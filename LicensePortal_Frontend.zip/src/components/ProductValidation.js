export default function Validate(values) {
    let errors = {};
    if (!values.prdName) {
      errors.prdName = 'Product Name is required';
    }
    if (!values.prdDesc) {
        errors.prdDesc = 'Product Description is required';
      }
      if (!values.productCode) {
        errors.productCode = 'Product Code is required';
      }
      if (!values.prdVersion) {
        errors.prdVersion = 'Product Version is required';
      }
  
    return errors;
  };
  