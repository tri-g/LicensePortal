import React,{useEffect,useState} from 'react'
function Pagenation(data){
const [offset, setOffset] = useState(0); 
const itemsPerPage = 5;
const changePage = offset => {
  setOffset(offset); 
};
let listItems = [];
  for (
    let i = offset * itemsPerPage;
    i < offset * itemsPerPage + itemsPerPage;
    i++
  ) {
    if (i >= data.length) {
      break;
    }
    listItems.push(data[i]);
  }

  const btns = [];
  for (let i = 1; i <= Math.ceil(data.length / itemsPerPage); i++) {
    const elem = (
      <span className="pagination-btn" onClick={() => changePage(i - 1)}>
        {i}
      </span>
    );
    btns.push(elem);
  }


  return {
    listItems,
    btns
  }
}
export default Pagenation;