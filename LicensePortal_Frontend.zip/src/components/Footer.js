import React from 'react'
import {Container} from "react-bootstrap";

function Footer() {
  return (
    <main>
  <div className="container1" style={{backgroundColor:"#F7F6FC",height:"7%",position:"fixed",bottom:"0",
   left:"0",right:"0",zIndex:"100" }}>
          <div className="bg-blue py-4">
            <div className="row px-3">
                <div className="row" style={{margin:"0 auto",color:"black",fontSize:".7em"}}> 
                      <span> &copy; 2021 SLK Software Services Pvt, Ltd. All Rights Reserved. </span> 
                </div>
            
            </div>
        </div>
       </div>
        </main>
  );
}

export default Footer;