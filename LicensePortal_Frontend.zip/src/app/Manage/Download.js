import React, {useEffect,useState} from 'react'
import {Col, Container, Row} from "react-bootstrap";
import {Link} from "react-router-dom";
import '../../assets/download.css';
import '../../assets/table.css';
import '../../assets/style.css';
import dll from '../../assets/Portable.Licensing.dll';
import jar from '../../assets/demo.jar';
import Service from "../service/service.js";

function Download() {
  var name=Service.readMessage();
console.log("from login  ",name);

  return (
     <div className="db-bg">
<link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300;1,400;1,600;1,700;1,800&display=swap" rel="stylesheet"/>

  <div className="container-fluid">

 <div className="dashboard">
                     
                    <div className="row row-border">      
                              <div className="col breadcrum"><span style={{position:"relative",left:"50px"}}>
                           <i className="fa fa-home" style={{paddingRight: "10px"}}></i><a href="/dashboard">Home</a>
                           - Download
                        </span></div>
                         <div className="col-7"></div>
                      <div className="col welcome"><h6 >Welcome {name}!</h6>
                          </div>
                    </div>

                 <div className="row break-row">        
                    
                    <div className="card card-outline-secondary card-box-download">
                        <div className="card-header" style={{background:"#f4f2f5"}}>
                           
                            <div className="row">
                                <div className="col-sm-6">
                                    <h3>jar</h3>
                                </div>
                                
                           </div>
                        </div>
                        <div className="card-body">
                            Sample Text Sample Text Sample Text
                            <div className="col-sm-6" style={{textAlign: "right",float:'right'}}>
                                    <a href={jar} download="Portable.Licensing.jar"><i className="fa fa-download"></i> Download</a>
                               </div>
                        </div>
                    </div>
                    <div className="card card-outline-secondary card-box-download" style={{marginTop:"20px"}}>
                        <div className="card-header" style={{background:"#f4f2f5"}}>
                           
                            <div className="row">
                                <div className="col-sm-6">
                                    <h3>dll</h3>
                                </div>
                                
                           </div>
                        </div>
                        <div className="card-body">
                            Sample Text Sample Text Sample Text
                            <div className="col-sm-6" style={{textAlign: "right",float:'right'}}>
                                    <a href={dll}  download="Portable.Licensing.dll"><i className="fa fa-download"></i> Download</a>
                               </div>
                        </div>
                    </div>
    
                </div>  
                </div>
                </div>



</div>

  )
}

export default Download
