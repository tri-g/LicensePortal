import React, {useEffect,useState} from 'react';
import Service from "../service/service.js";
import ProductsHistory from "../../components/ProductsHistory";
import '../../assets/g-icons.css';
import '../../assets/style.css';
import '../../assets/table1.css';
import { Modal} from "react-bootstrap";
import Validate from '../../components/ProductValidation';
import Pagenation from '../../components/Pagenation';
function ManageProducts()
{
 
  const initialState = 
  {
    productID: "",
    prdName: "",
    prdDesc:"",
    productCode: "",
    prdVersion: "",
    orgName:""
  };
  const [org, setOrg] = useState([]);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [data, setData] = useState([initialState]);
  const [submitted, setSubmitted] = useState(false);
  const [info, setInfo] = useState(initialState);
  const [fetching, setFetching] = useState(false)
  const handleShow = () =>{setShow(true);
    setShow1(true);
}
const [showModal, setShow] = useState(false);

  const handleShow1 = () => setShow1(true);
  const [show1, setShow1] = useState(false);

  const handleClose1 = () => {setShow1(false); setShow(false);}
  const [value, setValue] = useState(1);

  
  const handleClose = () => setShow(false);



  const fetch_learning_data = () =>
  {
    var results=[];
    Service.getProducts()
    .then(res => {
      results=res.data;
      setFetching(true);
      setData(results);
      console.log(results);
      setTimeout(() => {
        setFetching(false)
      }, 1000)
    }) 
    var results1=[];
    Service.getorganizationdetails()
    .then(res => {
      results1=res.data;
      setFetching(true);
      setOrg(results1);
      console.log(results1);
      setTimeout(() => {
        setFetching(false)
      }, 1000)
    })
  }
  
  var name=Service.readMessage();

  useEffect(() => {
    fetch_learning_data();
    console.log("im here 1");
    console.log(errors);
    if (Object.keys(errors).length === 0 && isSubmitting) {
      console.log("1s");   
      saveInfo();
   }
  }, [errors])

  const handleInputChange = event => {
    const { name, value } = event.target;
    setInfo({ ...info, [name]: value });
  };

  function success(){
    window.location.reload();
  }
  const handleSubmit = (event) => {
    if (event) event.preventDefault();
    setErrors(Validate(info));
    setIsSubmitting(true);
    console.log("im here");
    
  };
  const saveInfo = () => {
    var data = {
        prdName: info.prdName,
        prdDesc:info.prdDesc,
        productCode: info.productCode,
        prdVersion: info.prdVersion,
        orgID:+value
    };
    console.log(data);
    Service.addprod(data)
      .then(response => {
        setInfo({
        });

        setSubmitted(true);
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  };
  const {
    listItems,
    btns
  } = Pagenation(data);
  return(
  <div className="db-bg">
    <div className="container-fluid">
      <div className="dashboard" style={{height: "auto", maxHeight: "1400px"}}>
        <div className="row row-border">
          <div className="col-sm-6 breadcrum"><span style={{position: "relative",left:"50px"}}>
            <i className="fa fa-home" style={{paddingRight: "10px"}}></i><a href="/dashboard">Home</a>- Manage - Add Organization
            </span></div>
            <div className="col-4"></div>
            <div className="col welcome"><h6 >Welcome {name}!</h6>
            </div>
            </div>
                 <div className="row break-row" style={{marginBottom: "90px"}}>  
                    <div className="container">
                    <div className="row" style={{marginBottom: "20px"}}>
                               <span style={{display: "block", width: "50%"}}>
                                <button id="addNewRow" className="btn btn-sm" aria-hidden="true" data-toggle="modal" data-target="#myModal" onClick={handleShow} style={{width: "40%"}}>Add Product</button>
                            </span>
                               </div>
                        <div className="row">                         
                        <table className="table table-bordered table-striped table-hover table-condensed table-fixed text-center" id="DyanmicTable">
                                 <thead>
                                    <tr>
                                        <th className="text-center">Name</th>                                       
                                        <th className="text-center">Email</th>                                 
                                        <th className="text-center">Code</th>
                                        <th className="text-center">Version</th>  
                                        <th className="text-center">Organization</th>  

                                        <th></th>
                                    </tr>                                                                    
                                </thead>                              
        <tbody>               
        {listItems.map((k, v) => {
                   return <ProductsHistory key={v.toString()}
                                           last={data.length === v + 1}
                                           id={k.productID}
                                           name={k.prdName}
                                           desc={k.prdDesc}
                                           code={k.productCode} 
                                           version={k.prdVersion}  
                                           orgname={k.orgName}   
                                           org={org}      
                                           val={value}                      
                                           initialState={initialState}
                                          />
                                           
                 })}
                       </tbody> 
                       </table>  
                       {btns}          
                            </div>



                           
                       </div>
                  </div>
                         
               
       <Modal show={showModal} onHide={handleClose} style={{top:"5%"}}>      
      <div className="modal-dialog" style={{width: "100%",margin:"0px",padding:"0px"}}>
      <div className="modal-content">
      <div className="modal-header">
            <h5><strong>Add Product</strong></h5>
           <button type="button" className="close"  onClick={handleClose} data-dismiss="modal">&times;</button>
        </div>
        <div className="modal-body">
        {submitted ? (
        <div>
          <Modal show={show1} onHide={handleClose1} style={{top:"5%"}}>
          <div className="modal-body">
          <h3>Product Added Successfully!</h3>
       
          <input type="reset" className="btn btn-secondary" style={{width:"10%",float:"right",height:"3%"}} onClick={success} value="OK"/>
             
        </div>
      </Modal>
    </div>
      ) : (
            <form className="form" role="form" autoComplete="off" noValidate>
         
             
                <div className="form-group row">
                
                    <label className="col-lg-5 col-form-label form-control-label">Product Name</label>

                    <div className="col-lg-7">
             
                        <input className="form-control" type="text" id="prdName" name="prdName" onChange={handleInputChange} value={info.prdName || ''} required  placeholder="Product Name"/>
                        {errors.prdName && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.prdName}</p>
                  )}
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Description</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="prdDesc" name="prdDesc" onChange={handleInputChange} value={info.prdDesc || ''} required placeholder="Product Description"/>
                        {errors.prdDesc && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.prdDesc}</p>
                  )}
                    </div>
                </div>

                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Code</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="productCode" name="productCode" onChange={handleInputChange} value={info.productCode || ''} required placeholder="Product Code"/>
                        {errors.productCode && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.productCode}</p>
                  )}
                    </div>
                </div>

               <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Product Version</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="prdVersion" name="prdVersion" onChange={handleInputChange} value={info.prdVersion || ''} required placeholder="Product Version"/>
                        {errors.prdVersion && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.prdVersion}</p>
                  )}
                    </div>
                </div>
                <div className="form-group row">
            <label className="col-lg-5 col-form-label form-control-label" htmlFor="licensetype">Organization</label>
           <div className="col-lg-7">
             <select className="form-control selectpicker" id="select-country" data-live-search="true" name="org" value={value}
      onChange={(e) => setValue(e.currentTarget.value)}>
            
             {org.map((item,value) => (
        <option
          key={value}
          value={item.orgID}
        >
         {item.orgName}
        </option>
      ))}
          </select>
          
          </div></div>

            <div className="row" style={{padding:"10px"}}></div>
                <div className="form-group row">
                    <label className="col-lg-6 col-form-label form-control-label"></label>
                    <div className="col-lg-3">
                        <input type="reset" className="btn btn-secondary"  onClick={handleClose} value="Cancel"/>
                        </div>
                        <div className="col-lg-3">
                            <input type="submit" className="btn btn-primary" value="Add" onClick={handleSubmit} data-toggle="modal" data-target="#myModal"/>
                        </div>
                    </div>
                </form>
                )}

            </div>






        </div></div>
                                    </Modal>                    
                      
                        
     


    

 </div>
</div>
</div>

)
};

export default ManageProducts;