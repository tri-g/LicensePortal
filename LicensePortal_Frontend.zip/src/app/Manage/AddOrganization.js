import React, {useEffect,useState} from 'react'
import Service from "../service/service.js";
import OrganizationHistory from "../../components/OrganizationHistory";
import '../../assets/g-icons.css';
import '../../assets/style.css';
import '../../assets/table1.css';
import { Modal} from "react-bootstrap";
import { useHistory } from "react-router-dom";
import Validate from '../../components/OrganizationValidation';

function Manageorganization()
{
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const history = useHistory();
  const initialState = 
  {
    orgID: "",
    orgName: "",
    orgEmailAdd: "",
    orgConNumber: 0,
    orgAddress: "",
    postCode:0,
    OrgType_name:"",
    Description:""
  };

  const handleShow1 = () => setShow1(true);
  const [show1, setShow1] = useState(false);

  const handleClose1 = () => {setShow1(false); setShow(false);}
  const [value, setValue] = useState(1);

  const [showModal, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () =>{setShow(true);setShow1(true);}
  const [fetching, setFetching] = useState(false)
  const [data, setData] = useState([initialState]);

  const [submitted, setSubmitted] = useState(false);
  const [info, setInfo] = useState(initialState);


  const fetch_learning_data = () =>
  {
    var results=[];
    Service.getorganizationdetails()
    .then(res => {
      results=res.data;
      setFetching(true);
      setData(results);
      console.log(results);
      setTimeout(() => {
        setFetching(false)
      }, 1000)
    })
    
  }

  var name=Service.readMessage();
console.log()
  useEffect(() => {
    fetch_learning_data();
    console.log("im here 1");
    console.log(errors);
    if (Object.keys(errors).length === 0 && isSubmitting) {
      console.log("1s");   
      saveInfo();
   }
  }, [errors])
 
  const handleInputChange = event => {
    const { name, value } = event.target;
    setInfo({ ...info, [name]: value });
  };
  const handleSubmit = (event) => {
    if (event) event.preventDefault();
    setErrors(Validate(info));
    setIsSubmitting(true);
    console.log("im here");
    
  };
  function success(){
    window.location.reload();
  }
  const saveInfo = () => {
    var data = {
        orgID: +info.orgID,
        orgName: info.orgName,
        orgEmailAdd: info.orgEmailAdd,
        orgConNumber: info.orgConNumber,
        orgAddress: info.orgAddress,
        postCode:+info.postCode,
        OrgType_name:info.OrgType_name,
        Description:info.Description
       
    };
    console.log(data);
    Service.addorg(data)
      .then(response => {
        setInfo({
          orgID:response.data.orgID,
          orgName: response.data.orgName,
          orgEmailAdd: response.data.orgEmailAdd,
          orgConNumber: response.data.orgConNumber,
          orgAddress:response.data.orgAddress,
          postCode: response.data.postCode,
          OrgType_name: response.data.OrgType_name,
        Description:response.data.Description


        });

        setSubmitted(true);
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });
  };
  return(
  <div className="db-bg">
    <div className="container-fluid">
      <div className="dashboard" style={{height: "auto", maxHeight: "1400px"}}>
        <div className="row row-border">
          <div className="col-sm-6 breadcrum"><span style={{position: "relative",left:"50px"}}>
            <i className="fa fa-home" style={{paddingRight: "10px"}}></i><a href="/dashboard">Home</a>- Manage - Add Organization
            </span></div>
            <div className="col-4"></div>
            <div className="col welcome"><h6 >Welcome {name}!</h6>
            </div>
            </div>
                 <div className="row break-row" style={{marginBottom: "90px"}}>  
                    <div className="container">
                    <div className="row" style={{marginBottom: "20px"}}>
                               <span style={{display: "block", width: "50%"}}>
                                <button id="addNewRow" className="btn btn-sm" aria-hidden="true" data-toggle="modal" data-target="#myModal" onClick={handleShow} style={{width: "40%"}}>Add Organization</button>
                            </span>
                               </div>
                        <div className="row">                         
                        <table className="table table-bordered table-striped table-hover table-condensed table-fixed text-center" id="DyanmicTable">
                                 <thead>
                                    <tr>
                                        <th className="text-center">Name</th>                                       
                                        <th className="text-center">Email</th>                                 
                                        <th className="text-center">Contact No</th>
                                        <th className="text-center">Address </th>  
                                        <th className="text-center">Post Code</th>  

                                        <th></th>
                                    </tr>                                                                    
                                </thead>                              
        <tbody>               
        {data.map((k, v) => {
                   return <OrganizationHistory key={v.toString()}
                                           last={data.length === v + 1}
                                           id={k.orgID}
                                           name={k.orgName}
                                           email={k.orgEmailAdd}
                                           num={k.orgConNumber} address={k.orgAddress}
                                           postcode={k.postCode} 
                                           orgtype={k.orgType_name}  
                                           orgdes={k.description}                                  
                                           initialState={initialState}
                                          />
                                           
                 })}
                       </tbody> 
                       </table>            
                            </div>



                           
                       </div>
                  </div>
                         
               
      <Modal show={showModal} onHide={handleClose} style={{top:"5%"}}>      
      <div className="modal-dialog" style={{width: "100%",margin:"0px",padding:"0px"}}>
      <div className="modal-content">
      <div className="modal-header">
            <h5><strong>Add Organization</strong></h5>
           <button type="button" className="close"  onClick={handleClose} data-dismiss="modal">&times;</button>
        </div>
        <div className="modal-body">
        {submitted ? (
        <div>
          <Modal show={show1} onHide={handleClose1} style={{top:"5%"}}>
          <div className="modal-body">
          <h3>Organization Added Successfully!</h3>
       
          <input type="reset" className="btn btn-secondary" style={{width:"10%",float:"right",height:"3%"}} onClick={success} value="OK"/>
             
        </div>
      </Modal>
    </div>
      ) : (
            <form className="form" role="form" autoComplete="off" noValidate>
         
             
                <div className="form-group row">
                
                    <label className="col-lg-5 col-form-label form-control-label">Name</label>

                    <div className="col-lg-7">
                   
                        <input className="form-control" type="text" id="orgName" name="orgName" onChange={handleInputChange} value={info.orgName || ''} required  placeholder="Organization Name"/>
                        {errors.orgName && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.orgName}</p>
                  )}
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Email</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="email" id="orgEmailAdd" name="orgEmailAdd" onChange={handleInputChange} value={info.orgEmailAdd || ''} required placeholder="Email Address"/>
                        {errors.orgEmailAdd && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.orgEmailAdd}</p>
                  )}
                    </div>
                </div>

                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Contact No</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="orgConNumber" name="orgConNumber" onChange={handleInputChange} value={info.orgConNumber || ''} required placeholder="Contact Number"/>
                        {errors.orgConNumber && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.orgConNumber}</p>
                  )}
                    </div>
                </div>

               <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Address</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="orgAddress" name="orgAddress" onChange={handleInputChange} value={info.orgAddress || ''} required placeholder="Address"/>
                        {errors.orgAddress && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.orgAddress}</p>
                  )}
                    </div>
                </div>

                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Post Code</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="postCode" name="postCode" onChange={handleInputChange} value={info.postCode || ''} required placeholder="Post Code"/>
                        {errors.postCode && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.postCode}</p>
                  )}
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Organization Type</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="OrgType_name" name="OrgType_name" onChange={handleInputChange} value={info.OrgType_name || ''} required placeholder="Organization Type"/>
                        {errors.OrgType_name && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.OrgType_name}</p>
                  )}
                    </div>
                </div>
                <div className="form-group row">
                    <label className="col-lg-5 col-form-label form-control-label">Description</label>
                    <div className="col-lg-7">
                        <input className="form-control" type="text" id="Description" name="Description" onChange={handleInputChange} value={info.Description || ''} required placeholder="Description"/>
                        {errors.Description && (
                    <p style={{color:"red",fontSize:".7em"}}>{errors.Description}</p>
                  )}
                    </div>
                </div>

            <div className="row" style={{padding:"10px"}}></div>
                <div className="form-group row">
                    <label className="col-lg-6 col-form-label form-control-label"></label>
                    <div className="col-lg-3">
                        <input type="reset" className="btn btn-secondary"  onClick={handleClose} value="Cancel"/>
                        </div>
                        <div className="col-lg-3">
                            <input type="button" className="btn btn-primary" value="Add" onClick={handleSubmit} data-toggle="modal" data-target="#myModal"/>
                        </div>
                    </div>
                </form>
                )}

            </div>






        </div></div>
                                    </Modal>                   
                      
                        
     


    

 </div>
</div>
</div>

)
};

export default Manageorganization;