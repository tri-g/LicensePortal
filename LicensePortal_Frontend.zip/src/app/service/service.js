import http from "./http-common";

var message='';
var message1='';

const create = data => {
  return http.post("/GenerateLicense", data);
};

const login_validation = data => {
  return http.post("/token", data);
};

function getuserdetails() {
  return http.get('/token/GetUsers');
}

function setMessage(message){
  localStorage.setItem('message', JSON.stringify(message));
}

function readMessage(){
  var retrievedObject =localStorage.getItem('message');
  message1=JSON.parse(retrievedObject);
  return message1;
}
const deleteUser = id => {
  return http.delete("/token/DeleteUser/"+id);
};
const updateuser = (data,id) => {
  return http.put("/token/Update/"+id, data);
};
const adduser = data => {
  return http.post("/token/AddUser", data);
};
function getorganizationdetails() {
  return http.get('/token/GetOrganization');
}
const deleteOrganization = id => {
  return http.delete("/token/DeleteOrganization/"+id);
};
const addorg = data => {
  return http.post("/token/AddOrganization", data);
};
const updateorg = (data,id) => {
  return http.put("/token/Updateorg/"+id, data);
};
function getProducts() {
  return http.get('/token/Products');
}
const addprod = data => {
  return http.post("/token/AddProduct", data);
};
const updateprod = (data,id) => {
  return http.put("/token/UpdateProd/"+id, data);
};
const deleteProduct= id => {
  return http.delete("/token/DeleteProd/"+id);
};
export default {
  create,
  login_validation,
  setMessage,
  readMessage,
  getuserdetails,
  deleteUser,
  updateuser,
  adduser,
  getorganizationdetails,
  deleteOrganization,
  addorg,
  updateorg,
  getProducts,
  addprod,
  updateprod,
  deleteProduct
};