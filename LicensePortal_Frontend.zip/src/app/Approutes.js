import React, {lazy, Suspense} from 'react'
import {Route, Switch, useParams} from 'react-router-dom'
import {Spinner} from "react-bootstrap";

const Login = lazy(() => import('./Login/Login'))
const Dashboard = lazy(() => import('./Dashboard/Dashboard'))
const AddOrganization = lazy(() => import('./Manage/AddOrganization'))
const Report = lazy(() => import('./Report/Report'))
const licgen = lazy(() => import('./Manage/LicGen'))
const download = lazy(() => import('./Manage/Download.js'))
const adduser = lazy(() => import('./Manage/AddDeleteUser.js'))
const products = lazy(() => import('./Manage/Products.js'))


function AppRoutes() {
  let {impact_slug} = useParams();

  return (
    <Suspense fallback={<div className={'d-flex justify-content-center align-items-center'} style={{height: '90vh'}}>
      <Spinner animation="border"/>
    </div>}>
      <Switch>
        <Route exact path="/" component={Login}/>
        <Route exact path="/dashboard" component={Dashboard}/>
        <Route exact path="/addorganization/" component={AddOrganization}/>
        <Route exact path="/report/" component={Report}/>
        <Route exact path="/generation/" component={licgen}/>
        <Route exact path="/download/" component={download}/>
        <Route exact path="/adddeleteuser/" component={adduser}/>
        <Route exact path="/products/" component={products}/>

      </Switch>
    </Suspense>
  )
}

export default AppRoutes
